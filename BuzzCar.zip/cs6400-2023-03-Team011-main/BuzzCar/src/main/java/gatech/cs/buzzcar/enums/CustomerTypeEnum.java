package gatech.cs.buzzcar.enums;

public enum CustomerTypeEnum {
    Business,
    Individual
}
