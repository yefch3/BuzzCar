package gatech.cs.buzzcar.service;

import gatech.cs.buzzcar.entity.pojo.VehicleType;

import java.util.List;

public interface VehicleTypeService {
    List<VehicleType> queryVehicleTypes();
}
