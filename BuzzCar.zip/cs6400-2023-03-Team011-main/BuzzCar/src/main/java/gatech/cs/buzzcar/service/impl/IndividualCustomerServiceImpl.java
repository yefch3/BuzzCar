package gatech.cs.buzzcar.service.impl;


import gatech.cs.buzzcar.service.IndividualCustomerService;
import org.springframework.stereotype.Service;

@Service
public class IndividualCustomerServiceImpl implements IndividualCustomerService {

}
