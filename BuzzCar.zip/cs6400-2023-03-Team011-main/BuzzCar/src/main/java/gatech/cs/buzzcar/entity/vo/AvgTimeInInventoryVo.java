package gatech.cs.buzzcar.entity.vo;

import lombok.Data;

@Data
public class AvgTimeInInventoryVo {

    private String vehicleType;

    private String averageTimeInInventory;
}
