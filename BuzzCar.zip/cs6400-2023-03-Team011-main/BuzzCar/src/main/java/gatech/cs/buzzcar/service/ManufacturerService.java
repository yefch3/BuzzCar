package gatech.cs.buzzcar.service;

import gatech.cs.buzzcar.entity.pojo.Manufacturer;

import java.util.List;

public interface ManufacturerService {


    List<Manufacturer> queryList();
}
