package gatech.cs.buzzcar.service;

@Deprecated
public interface PartService {
}
