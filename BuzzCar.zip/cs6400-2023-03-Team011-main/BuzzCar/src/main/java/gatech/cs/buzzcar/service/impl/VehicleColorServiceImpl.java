package gatech.cs.buzzcar.service.impl;

import gatech.cs.buzzcar.service.VehicleColorService;
import org.springframework.stereotype.Service;

@Deprecated
@Service
public class VehicleColorServiceImpl implements VehicleColorService {
}
