package gatech.cs.buzzcar.service;

public interface IndividualCustomerService {
}
