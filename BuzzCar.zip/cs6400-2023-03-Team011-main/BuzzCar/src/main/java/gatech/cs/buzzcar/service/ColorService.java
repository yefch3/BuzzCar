package gatech.cs.buzzcar.service;

import gatech.cs.buzzcar.entity.pojo.Color;

import java.util.List;

public interface ColorService {


    List<Color> queryColors();
}
