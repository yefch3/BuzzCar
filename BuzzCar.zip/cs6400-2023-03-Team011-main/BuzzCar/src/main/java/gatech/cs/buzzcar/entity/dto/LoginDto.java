package gatech.cs.buzzcar.entity.dto;

import lombok.Data;

@Data
public class LoginDto {

    private String username;
    private String password;

}
