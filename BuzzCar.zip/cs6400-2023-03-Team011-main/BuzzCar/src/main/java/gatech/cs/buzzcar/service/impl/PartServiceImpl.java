package gatech.cs.buzzcar.service.impl;

import gatech.cs.buzzcar.service.PartService;
import org.springframework.stereotype.Service;

@Deprecated
@Service
public class PartServiceImpl implements PartService {
}
