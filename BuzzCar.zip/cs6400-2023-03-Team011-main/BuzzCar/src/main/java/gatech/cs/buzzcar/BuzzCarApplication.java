package gatech.cs.buzzcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuzzCarApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuzzCarApplication.class, args);
    }

}
