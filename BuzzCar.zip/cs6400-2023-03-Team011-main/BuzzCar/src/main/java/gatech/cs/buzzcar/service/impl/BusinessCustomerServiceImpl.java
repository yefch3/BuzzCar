package gatech.cs.buzzcar.service.impl;

import gatech.cs.buzzcar.service.BusinessCustomerService;
import org.springframework.stereotype.Service;

@Service
public class BusinessCustomerServiceImpl implements BusinessCustomerService {


}
