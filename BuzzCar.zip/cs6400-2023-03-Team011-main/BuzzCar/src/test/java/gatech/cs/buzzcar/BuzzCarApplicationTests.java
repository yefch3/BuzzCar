package gatech.cs.buzzcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuzzCarApplicationTests {

    @Test
    void contextLoads() {
    }

}
